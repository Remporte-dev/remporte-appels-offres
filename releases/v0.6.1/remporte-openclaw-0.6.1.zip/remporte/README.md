# Compétences Remporte

Copiez les six sous-dossiers de `skills/` dans `~/.openclaw/skills`. Chaque compétence est autonome avec ses fichiers de référence.
