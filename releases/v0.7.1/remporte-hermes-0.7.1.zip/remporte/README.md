# Compétences Remporte

Copiez les sous-dossiers de `skills/` dans `~/.hermes/skills`. Chaque compétence est autonome avec ses fichiers de référence.
