# Compétences Remporte

Copiez les sous-dossiers de `skills/` dans `~/.pi/agent/skills`. Chaque compétence est autonome avec ses fichiers de référence.
