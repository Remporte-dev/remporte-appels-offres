---
name: remporte-fichier-impose
description: Remplir un questionnaire, une annexe technique ou tout fichier Excel ou Word fourni par l'acheteur d'un marché public, dans son propre fichier, sans changer sa structure ni ses formules.
---
# Fichier imposé par l'acheteur

Vérifie que tu peux lancer des commandes et lire/écrire les fichiers du dossier choisi. Il faut les deux capacités. Si l'une manque, explique que cette tâche demande un environnement avec accès aux commandes et aux fichiers, comme Codex, Claude Code/Cowork ou ChatGPT Work disposant de cet accès. Ne poursuis pas sans ces capacités.

Suis `remporte guide excel` : une copie dans `reponse/`, seules les cases
prévues pour le candidat sont remplies, le contenu vient du mémoire et de la
base. Relis le fichier case par case avant de le déclarer prêt. Bordereau de
prix : skill `remporte-chiffrage`.

Exécute les commandes depuis le dossier de réponse (celui qui contient `.remporte/`).
Depuis un autre dossier, utilise `--dossier "<chemin>"` seulement si l'aide de la commande
propose cette option ; `remporte guide <étape>` ne la prend pas. Pas encore de dossier : la compétence `remporte-nouvel-ao`.
N'invente jamais une information sur l'entreprise : `remporte fiche`,
`remporte base chercher`, ou `[à compléter : …]`.
