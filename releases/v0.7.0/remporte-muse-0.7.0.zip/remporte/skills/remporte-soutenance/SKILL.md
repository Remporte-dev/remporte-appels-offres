---
name: remporte-soutenance
description: Préparer la soutenance orale d'une réponse à appel d'offres public : déroulé calé sur les critères du RC, support PowerPoint dans le modèle de l'entreprise, questions probables de l'acheteur.
---
# Soutenance

Vérifie que tu peux lancer des commandes et lire/écrire les fichiers du dossier choisi. Il faut les deux capacités. Si l'une manque, explique que cette tâche demande un environnement avec accès aux commandes et aux fichiers, comme Codex, Claude Code/Cowork ou ChatGPT Work disposant de cet accès. Ne poursuis pas sans ces capacités.

Suis `remporte guide soutenance` : demande d'abord le modèle PowerPoint ou
Keynote de l'entreprise et les consignes du RC, écris le déroulé dans
`06-soutenance.md`, puis compose le support avec tes propres outils.

Exécute les commandes depuis le dossier de réponse (celui qui contient `.remporte/`).
Depuis un autre dossier, utilise `--dossier "<chemin>"` seulement si l'aide de la commande
propose cette option ; `remporte guide <étape>` ne la prend pas. Pas encore de dossier : la compétence `remporte-nouvel-ao`.
N'invente jamais une information sur l'entreprise : `remporte fiche`,
`remporte base chercher`, ou `[à compléter : …]`.
