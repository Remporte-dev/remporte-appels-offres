# Compétences Remporte

Copiez les sous-dossiers de `skills/` dans `un dossier de votre choix`. Chaque compétence est autonome avec ses fichiers de référence.
