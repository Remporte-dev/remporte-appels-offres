# Compétences Remporte

Copiez les sous-dossiers de `skills/` dans `~/.openclaw/skills`. Chaque compétence est autonome avec ses fichiers de référence.
