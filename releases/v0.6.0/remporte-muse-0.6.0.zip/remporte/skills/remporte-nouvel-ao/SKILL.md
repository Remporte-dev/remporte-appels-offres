---
name: remporte-nouvel-ao
description: Démarrer la réponse à un nouvel appel d'offres public à partir de son DCE (zip ou dossier), puis la conduire étape par étape avec l'utilisateur jusqu'aux fichiers à déposer. À lancer quand l'utilisateur tape remporte-nouvel-ao, éventuellement suivi du chemin du DCE.
---
# Nouvel appel d'offres

Prends le chemin du DCE indiqué dans le message ou dans les arguments de la commande ; s'il manque, demande-le dans la conversation.

Tu conduis la réponse avec l'utilisateur. Une étape à la fois ; à chaque point
de décision, tu t'arrêtes et tu lui demandes. Français simple, sans jargon
informatique.

Vérifie que tu peux lancer des commandes et lire/écrire les fichiers du dossier choisi. Il faut les deux capacités. Si l'une manque, explique que la tâche demande un environnement avec accès aux commandes et aux fichiers, comme Codex, Claude Code/Cowork ou ChatGPT Work disposant de cet accès. Arrête cette étape si ces accès manquent.

Lance `remporte --version`. Remporte CLI est une dépendance externe. Si la commande est absente, propose la compétence `remporte-init` pour suivre l'installation. Ne promets pas que l'installation du plugin installe le CLI.

## 1. Le DCE

Demande où se trouve le DCE téléchargé (zip de la plateforme ou dossier décompressé) s'il n'est pas déjà indiqué dans la conversation.

Travaille depuis l'espace de travail de l'entreprise (le dossier qui contient
`ressources/` et `DCEs/`) : `remporte init "<DCE>"` y crée
`DCEs/<nom du DCE>/`. Si aucun espace n'existe, propose la compétence `remporte-init`.

Toutes les commandes suivantes prennent
`--dossier "<chemin du dossier de réponse>"` si tu n'es pas lancé dedans.

## 2. Premier état du dossier

Lis `01-pieces.md` et `remporte formats`, puis résume en cinq lignes au plus :
pièces trouvées, pièces illisibles ou manquantes (le RC surtout), cadre de
réponse imposé ou non, contraintes de forme (pages, fichier à compléter,
soutenance). Signale ce qui bloque.

## 3. Trois questions à l'utilisateur, avant d'analyser

1. Quels lots l'intéressent, s'il y en a plusieurs ?
2. Quelle est sa date limite interne (souvent quelques jours avant celle de
   l'acheteur) ?
3. Veut-il valider à chaque étape, ou seulement au go/no-go et à la fin ?

## 4. Le parcours avec les compétences Remporte

Utilise d'abord les compétences Remporte indiquées dans le tableau. Si une compétence manque, transmets la procédure à un sous-agent générique si l'environnement en propose un. Si tu exécutes toi-même une étape faute de sous-agent, indique clairement cette limite à l'utilisateur : cette étape ne bénéficie alors pas d'une contribution indépendante.

| Étape | Procédure |
|---|---|
| Index et analyse | compétence `remporte-lecture-dce`, [lecture du DCE](references/lecture-dce.md) |
| Go/No-Go | avec l'utilisateur, `remporte guide go-no-go`, analyse et `remporte fiche` |
| Plan | `remporte guide plan` |
| Rédaction | compétence `remporte-redaction-section`, [rédaction d'une section](references/redaction-section.md) |
| Relecture | compétence `remporte-relecture-ao`, [relecture](references/relecture-ao.md) |
| Export | `remporte exporter` |

Donne à chaque lecteur le chemin du dossier ; il écrit `00-index.md` et `02-analyse.md`. Pour la rédaction, donne une section par agent et lance-les par lots de trois ou quatre si les outils disponibles le permettent, les plus pondérées d'abord. Coche le plan après réception de chaque section. Le relecteur écrit `05-relecture.md` ; tu appliques ensuite ses corrections.

Pour chaque étape, utilise la compétence Remporte correspondante. Si elle n'est pas disponible, transmets la procédure et le dossier à un sous-agent générique si l'environnement en propose un. Sinon, réalise toi-même l'étape avec `remporte guide <étape>` et signale que tu n'as pas eu de contribution indépendante. Pendant la relecture, ne modifie aucune section.

Trois arrêts obligatoires, quel que soit le mode choisi :

- **après l'analyse** : présente les critères pondérés et les points de
  vigilance, demande s'il manque quelque chose ;
- **au go/no-go** : la décision appartient à l'utilisateur. Présente ta
  recommandation et ses raisons, et attends sa réponse ;
- **après le plan** : fais valider la trame avant de rédiger.

Pendant la rédaction, regroupe les informations manquantes et pose-les
ensemble, plutôt qu'une par une.

## 5. La fin

Après `remporte exporter`, donne à l'utilisateur :
- les fichiers produits (`export/`, `candidature/` s'il y a lieu) ;
- la liste de ce qu'il doit encore fournir, signer ou remplir ;
- la date limite de remise, rappelée.

Ouvre-lui `export/feuille-de-route.html` s'il le souhaite : c'est le
récapitulatif à garder sous les yeux jusqu'au dépôt.
