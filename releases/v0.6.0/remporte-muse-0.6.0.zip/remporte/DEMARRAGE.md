# Remporte dans Muse

Ce paquet contient le CLI et six compétences autonomes. Il n'est pas un connecteur publié dans un annuaire.

## Demande à donner à votre agent

Lis ce fichier et vérifie que tu peux exécuter des commandes, lire et écrire les fichiers de cet environnement. Si ces accès manquent, arrête et explique la limite. N'utilise aucun chemin de mon ordinateur personnel.

Vérifie `remporte --version`. Pour installer cette version, propose `uv tool install ./cli/remporte-0.6.0-py3-none-any.whl` depuis le dossier de ce paquet et attends mon accord. Si uv manque, propose la procédure officielle https://docs.astral.sh/uv/getting-started/installation/ ; respecte les autorisations réseau et installation de la plateforme. Ne prétends pas que l'outil est installé avant une vérification réussie de sa version.

Lis `skills/remporte-init/SKILL.md` et accompagne-moi pour choisir un dossier de travail dans cet environnement. Demande mes documents d'entreprise et mon DCE, puis utilise les fichiers que j'y ai fournis. Lis ensuite `skills/remporte-nouvel-ao/SKILL.md` pour conduire la réponse. Chaque compétence contient ses propres références dans references/. Les autres compétences sont dans skills/. Si ta plateforme permet d'enregistrer des compétences personnalisées, utilise son mécanisme documenté ; sinon lis ces fichiers directement à chaque étape. N'invente pas un dossier système de compétences.

Conserve les validations de l'analyse, du go/no-go et du plan avant la rédaction. Ne fabrique aucune référence, aucun effectif ni certification. Si aucun agent indépendant ne peut relire, signale que la relecture a lieu dans le même contexte. Remets les exports Word, HTML et Excel via le mécanisme de fichiers de cette plateforme. Ne publie et ne dépose jamais la réponse à un marché sans ma demande.
